<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>File Authentication</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

    <header>
        <h1>REGISTRATION AND LOGIN FORM</h1>
    </header>

    <div class="container">
        <div class="reg">
        <form action="reg.php" method="POST">
            <h2>Sign Up</h2>
            <!-- <label>First Name:</label><br>
            <input type="text" name="fname" placeholder="First Name" required="required" /><br><br>
            <label>Last Name:</label><br>
            <input type="text" name="lname" placeholder="Last Name" required="required" /><br><br> -->
            <label>Username:</label><br>
            <input type="text" name="uname" placeholder="Userame" required="required" /><br><br>
            <label>Password:</label><br>
            <input type="password" name="pword" placeholder="Password" required="required" /><br><br>
            <input type="submit" name="submit" value="Save" />
            <p>If you are not registered yet, please fill in your details</p>
        </form>
        </div>

        <div class="login">
        <form action="login.php" method="POST">
        <h2>Login</h2>
            <label>Username:</label><br>
            <input type="text" name="uname" placeholder="Userame" required="required" /><br><br>
            <label>Password:</label><br>
            <input type="password" name="pword" placeholder="Password" required="required" /><br><br>
            <input type="submit" name="login" value="Login" />
           <!-- <button type="delete" name="deletebtn">Delete</button> -->
            <p>If you are registered already please enter your login details to verify!</p>
        </form>
        </div>
    </div>

    <footer>
        &copyCopyright Honestsammie 2021. All right reserved.
    </footer>

</body>