<?php

    if(isset($_POST['submit'])){

        //$first_name = $_POST['fname'];
        //$last_name = $_POST['lname'];
        $username = $_POST['uname'];
        $password = $_POST['pword'];

    $file = fopen("data.txt", "a");
     fputs($file, $username." | ".$password."\r\n");
     fclose($file);

   /*  $array_data = [
        'uname' => $username,
        'pword' => $password
    ];

     file_put_contents('Files/'. $array_data['uname']. ".json", json_encode($array_data)); */
     header('Location: index.php');
        

    }else{
        echo"Submittion was not Successfully";
    }
?>