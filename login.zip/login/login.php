<?php
 
if(isset($_POST['login'])){
        //echo "Login Successful";
        
        $username = $_POST['uname'];
        $password = $_POST['pword'];
        
        $file = fopen('data.txt', 'r');
        
        $success = false;
        while(!feof($file)){
            $line = fgets($file);
            $array_data = explode("|", $line);
            if($array_data[0] == $username && $array_datat[1] == $password){
                $success = true;
                break;
            }
        }

        if($success){
            echo "Logged in Successfully";
        }else{
            echo "Something went wrong, Try again";
        }
        fclose($file);
    }

?>